package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController //error
class ServerController{
    
	@RequestMapping("/hash") //error
    public String myHash(){
    	String data = "Hello, this is my checksum! My name is Rachel Siminski!";
       
    	try {
    		String checksum = generateChecksum(data);
    		return "<p>Data: " + data + "</p><p>SHA-256 Checksum: " + checksum + "</p>";
    	}
    	catch (NoSuchAlgorithmException e) {
    		return "Error: " + e.getMessage();
    	}
    }
	
	// Generate SHA-256 checksum
	public static String generateChecksum(String data) throws NoSuchAlgorithmException {
		// Initialize and declare a message digest instance
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		
		// Convert data string into bytes
		byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
		
		// Convert hash from bytes to hexadecimal
		StringBuilder hexString = new StringBuilder();
		// For each byte in hash
		for (byte bytes : hash) {
			// Convert bytes to unsigned bytes then convert to hexadecimal
			String hex = Integer.toHexString(0xff & bytes);
			// If hex length is 1
			if (hex.length() == 1) {
				// Append 0 to the end of hex string
				hexString.append('0');
			}
			// Append hex to the end of hex string
			hexString.append(hex);
		}
		
		// Return hex string: checksum value
		return hexString.toString();
	}
}
